# Character Creator

Ein vollständiger Character Creator für TSX/Vite Projekte.

## Installation

1. Kopiere den gesamten `CharacterCreator` Ordner in dein Projekt
2. Installiere die benötigten Dependencies:

\`\`\`bash
npm install lucide-react
\`\`\`

## Verwendung

\`\`\`tsx
import { CharacterCreator } from './CharacterCreator'

function App() {
  return <CharacterCreator />
}
\`\`\`

## Features

- 4 Steps: Geschlecht & Eltern, Gesichtszüge, Herkunft, Aussehen
- Vollständig anpassbare Character-Optionen
- Zufalls-Generator
- Reset-Funktion
- Modal zum Fertigstellen (Name, Geburtsdatum)
- Regeln-Modal
- Modernes Dark Theme mit Cyan-Akzentfarbe (#1aaff1)
- Vollständig responsive

## Struktur

\`\`\`
CharacterCreator/
├── index.tsx              # Haupt-Component
├── styles.css             # Alle Styles
├── components/
│   ├── Steps.tsx          # Navigation
│   ├── Panel.tsx          # Side Panel Container
│   ├── BottomButtons.tsx  # Buttons unten
│   ├── FinishModal.tsx    # Fertigstellen-Modal
│   ├── RulesModal.tsx     # Regeln-Modal
│   ├── panels/
│   │   ├── GenderPanel.tsx
│   │   ├── ParentsPanel.tsx
│   │   ├── FeaturesPanel.tsx
│   │   ├── HeritagePanel.tsx
│   │   └── AppearancePanel.tsx
│   └── controls/
│       ├── SelectControl.tsx
│       ├── RangeControl.tsx
│       └── ColorControl.tsx
└── README.md
\`\`\`

## Anpassung

Die Akzentfarbe kann in `styles.css` geändert werden:

\`\`\`css
:root {
  --accent-color: #1aaff1; /* Deine Farbe hier */
}
