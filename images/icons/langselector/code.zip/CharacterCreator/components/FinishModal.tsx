"use client"

import { X } from "lucide-react"
import type { CharacterData } from "../index"

interface FinishModalProps {
  characterData: CharacterData
  onClose: () => void
  onConfirm: () => void
  updateCharacterData: (updates: Partial<CharacterData>) => void
}

export function FinishModal({ characterData, onClose, onConfirm, updateCharacterData }: FinishModalProps) {
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2 className="modal-title">Charakter fertigstellen</h2>
          <button onClick={onClose} className="modal-close">
            <X />
          </button>
        </div>
        <div className="modal-body">
          <div className="input-group">
            <label className="input-label">Vorname</label>
            <input
              type="text"
              className="input-field"
              placeholder="Max"
              value={characterData.firstName}
              onChange={(e) => updateCharacterData({ firstName: e.target.value })}
            />
          </div>
          <div className="input-group">
            <label className="input-label">Nachname</label>
            <input
              type="text"
              className="input-field"
              placeholder="Mustermann"
              value={characterData.lastName}
              onChange={(e) => updateCharacterData({ lastName: e.target.value })}
            />
          </div>
          <div className="input-group">
            <label className="input-label">Geburtsdatum</label>
            <input
              type="date"
              className="input-field"
              value={characterData.dateOfBirth}
              onChange={(e) => updateCharacterData({ dateOfBirth: e.target.value })}
            />
          </div>
          <div className="modal-buttons">
            <button onClick={onClose} className="modal-button modal-button-secondary">
              Abbrechen
            </button>
            <button onClick={onConfirm} className="modal-button modal-button-primary">
              Bestätigen
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
