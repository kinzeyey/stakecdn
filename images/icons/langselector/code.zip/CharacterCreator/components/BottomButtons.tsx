"use client"

import { Shuffle, RotateCcw, Check, FileText } from "lucide-react"

interface BottomButtonsProps {
  onRandomize: () => void
  onReset: () => void
  onFinish: () => void
  onRules: () => void
}

export function BottomButtons({ onRandomize, onReset, onFinish, onRules }: BottomButtonsProps) {
  return (
    <div className="bottom-buttons">
      <button onClick={onRandomize} className="bottom-button">
        <Shuffle />
        <span className="button-tooltip">Zufällig</span>
      </button>
      <button onClick={onReset} className="bottom-button">
        <RotateCcw />
        <span className="button-tooltip">Zurücksetzen</span>
      </button>
      <button onClick={onFinish} className="bottom-button">
        <Check />
        <span className="button-tooltip">Fertigstellen</span>
      </button>
      <button onClick={onRules} className="bottom-button">
        <FileText />
        <span className="button-tooltip">Regeln</span>
      </button>
    </div>
  )
}
