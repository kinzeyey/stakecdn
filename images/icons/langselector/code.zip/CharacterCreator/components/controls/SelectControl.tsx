"use client"

interface SelectControlProps {
  label: string
  value: number
  options: { value: number; label: string }[]
  onChange: (value: number) => void
}

export function SelectControl({ label, value, options, onChange }: SelectControlProps) {
  return (
    <div className="control-group">
      <label className="control-label">{label}</label>
      <div className="select-buttons">
        {options.map((option) => (
          <button
            key={option.value}
            onClick={() => onChange(option.value)}
            className={`select-button ${value === option.value ? "active" : ""}`}
          >
            {option.label}
          </button>
        ))}
      </div>
    </div>
  )
}
