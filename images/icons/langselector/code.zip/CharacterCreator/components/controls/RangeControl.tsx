"use client"

interface RangeControlProps {
  label: string
  value: number
  min: number
  max: number
  onChange: (value: number) => void
}

export function RangeControl({ label, value, min, max, onChange }: RangeControlProps) {
  return (
    <div className="control-group">
      <div className="range-header">
        <label className="control-label">{label}</label>
        <span className="range-value">{value}</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="range-slider"
      />
    </div>
  )
}
