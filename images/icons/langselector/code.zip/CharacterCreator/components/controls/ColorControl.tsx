"use client"

interface ColorControlProps {
  label: string
  value: number
  colors: string[]
  onChange: (value: number) => void
}

export function ColorControl({ label, value, colors, onChange }: ColorControlProps) {
  return (
    <div className="control-group">
      <label className="control-label">{label}</label>
      <div className="color-picker-grid">
        {colors.map((color, index) => (
          <button
            key={index}
            onClick={() => onChange(index)}
            className={`color-button ${value === index ? "active" : ""}`}
            style={{ backgroundColor: color }}
          />
        ))}
      </div>
    </div>
  )
}
