"use client"

import type React from "react"
import type { Step } from "../index"
import { Users, Scan, Globe, Sparkles } from "lucide-react"

interface StepsProps {
  currentStep: Step
  onStepClick: (step: Step) => void
}

const steps: { id: Step; icon: React.ReactNode; title: string }[] = [
  { id: "genderParents", icon: <Users />, title: "Geschlecht & Eltern" },
  { id: "features", icon: <Scan />, title: "Gesichtszüge" },
  { id: "heritage", icon: <Globe />, title: "Herkunft" },
  { id: "appearance", icon: <Sparkles />, title: "Aussehen" },
]

export function Steps({ currentStep, onStepClick }: StepsProps) {
  return (
    <div className="steps-container">
      {steps.map((step) => (
        <button
          key={step.id}
          onClick={() => onStepClick(step.id)}
          className={`step-button ${currentStep === step.id ? "active" : ""}`}
        >
          <span className="step-button-icon">{step.icon}</span>
          <span className="step-button-tooltip">{step.title}</span>
        </button>
      ))}
    </div>
  )
}
