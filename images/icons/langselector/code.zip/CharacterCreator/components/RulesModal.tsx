"use client"

import { X } from "lucide-react"

interface RulesModalProps {
  onClose: () => void
}

export function RulesModal({ onClose }: RulesModalProps) {
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2 className="modal-title">Regeln</h2>
          <button onClick={onClose} className="modal-close">
            <X />
          </button>
        </div>
        <div className="modal-body">
          <div className="rules-text">
            <h3>Character Creator Regeln</h3>
            <ul>
              <li>Erstelle deinen einzigartigen Charakter</li>
              <li>Wähle Geschlecht und Eltern aus</li>
              <li>Passe Gesichtszüge individuell an</li>
              <li>Bestimme die Herkunft deines Charakters</li>
              <li>Gestalte das Aussehen nach deinen Wünschen</li>
              <li>Nutze die Zufallsfunktion für Inspiration</li>
              <li>Alle Einstellungen können jederzeit geändert werden</li>
            </ul>
          </div>
          <div className="modal-buttons">
            <button onClick={onClose} className="modal-button modal-button-primary">
              Verstanden
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
