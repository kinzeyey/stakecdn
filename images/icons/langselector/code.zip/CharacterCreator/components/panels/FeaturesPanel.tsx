"use client"

import type { CharacterData } from "../../index"
import { SelectControl } from "../controls/SelectControl"
import { RangeControl } from "../controls/RangeControl"

interface FeaturesPanelProps {
  features: CharacterData["features"]
  updateCharacterData: (updates: Partial<CharacterData>) => void
}

export function FeaturesPanel({ features, updateCharacterData }: FeaturesPanelProps) {
  const updateFeatures = (key: keyof CharacterData["features"], value: number) => {
    updateCharacterData({ features: { ...features, [key]: value } })
  }

  return (
    <div className="panel-section">
      <h3 className="panel-title">Gesichtszüge</h3>
      <SelectControl
        label="Gesicht"
        value={features.face}
        options={Array.from({ length: 21 }, (_, i) => ({ value: i, label: `${i}` }))}
        onChange={(value) => updateFeatures("face", value)}
      />
      <SelectControl
        label="Nase"
        value={features.nose}
        options={Array.from({ length: 21 }, (_, i) => ({ value: i, label: `${i}` }))}
        onChange={(value) => updateFeatures("nose", value)}
      />
      <RangeControl
        label="Nasenneigung"
        value={features.noseTilt}
        min={0}
        max={100}
        onChange={(value) => updateFeatures("noseTilt", value)}
      />
      <SelectControl
        label="Augenbrauen"
        value={features.eyebrows}
        options={Array.from({ length: 34 }, (_, i) => ({ value: i, label: `${i}` }))}
        onChange={(value) => updateFeatures("eyebrows", value)}
      />
      <RangeControl
        label="Augenbrauenhöhe"
        value={features.eyebrowHeight}
        min={0}
        max={100}
        onChange={(value) => updateFeatures("eyebrowHeight", value)}
      />
      <SelectControl
        label="Augen"
        value={features.eyes}
        options={Array.from({ length: 32 }, (_, i) => ({ value: i, label: `${i}` }))}
        onChange={(value) => updateFeatures("eyes", value)}
      />
    </div>
  )
}
