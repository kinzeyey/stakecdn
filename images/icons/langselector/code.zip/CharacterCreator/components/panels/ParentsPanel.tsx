"use client"

import type { CharacterData } from "../../index"

interface ParentsPanelProps {
  parents: CharacterData["parents"]
  updateCharacterData: (updates: Partial<CharacterData>) => void
}

export function ParentsPanel({ parents, updateCharacterData }: ParentsPanelProps) {
  const generateParentOptions = (count: number) => {
    return Array.from({ length: count }, (_, i) => i)
  }

  return (
    <div className="panel-section">
      <h3 className="panel-title">Eltern</h3>
      <div className="parents-container">
        <div className="parent-section">
          <div className="parent-label">Mutter</div>
          <div className="parent-images">
            {generateParentOptions(46).map((i) => (
              <button
                key={i}
                onClick={() => updateCharacterData({ parents: { ...parents, mother: i } })}
                className={`parent-image-button ${parents.mother === i ? "active" : ""}`}
              >
                <img src={`/mother-.jpg?height=80&width=80&query=mother-${i}`} alt={`Mutter ${i}`} />
              </button>
            ))}
          </div>
        </div>
        <div className="parent-section">
          <div className="parent-label">Vater</div>
          <div className="parent-images">
            {generateParentOptions(46).map((i) => (
              <button
                key={i}
                onClick={() => updateCharacterData({ parents: { ...parents, father: i } })}
                className={`parent-image-button ${parents.father === i ? "active" : ""}`}
              >
                <img src={`/father-.jpg?height=80&width=80&query=father-${i}`} alt={`Vater ${i}`} />
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
