"use client"

import type { CharacterData } from "../../index"
import { SelectControl } from "../controls/SelectControl"
import { RangeControl } from "../controls/RangeControl"

interface HeritagePanelProps {
  heritage: CharacterData["heritage"]
  updateCharacterData: (updates: Partial<CharacterData>) => void
}

export function HeritagePanel({ heritage, updateCharacterData }: HeritagePanelProps) {
  const updateHeritage = (key: keyof CharacterData["heritage"], value: number) => {
    updateCharacterData({ heritage: { ...heritage, [key]: value } })
  }

  return (
    <div className="panel-section">
      <h3 className="panel-title">Herkunft</h3>
      <SelectControl
        label="Vater Herkunft"
        value={heritage.fatherHeritage}
        options={Array.from({ length: 22 }, (_, i) => ({ value: i, label: `Herkunft ${i}` }))}
        onChange={(value) => updateHeritage("fatherHeritage", value)}
      />
      <SelectControl
        label="Mutter Herkunft"
        value={heritage.motherHeritage}
        options={Array.from({ length: 22 }, (_, i) => ({ value: i, label: `Herkunft ${i}` }))}
        onChange={(value) => updateHeritage("motherHeritage", value)}
      />
      <RangeControl
        label="Ähnlichkeit"
        value={heritage.resemblance}
        min={0}
        max={100}
        onChange={(value) => updateHeritage("resemblance", value)}
      />
    </div>
  )
}
