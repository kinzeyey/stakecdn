"use client"

import type { CharacterData } from "../../index"
import { SelectControl } from "../controls/SelectControl"

interface GenderPanelProps {
  gender: number
  updateCharacterData: (updates: Partial<CharacterData>) => void
}

export function GenderPanel({ gender, updateCharacterData }: GenderPanelProps) {
  const genderOptions = [
    { value: 0, label: "Weiblich" },
    { value: 50, label: "Neutral" },
    { value: 100, label: "Männlich" },
  ]

  return (
    <div className="panel-section">
      <h3 className="panel-title">Geschlecht</h3>
      <SelectControl
        label="Wähle dein Geschlecht"
        value={gender}
        options={genderOptions}
        onChange={(value) => updateCharacterData({ gender: value })}
      />
    </div>
  )
}
