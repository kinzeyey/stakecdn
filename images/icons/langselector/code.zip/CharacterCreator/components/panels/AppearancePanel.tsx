"use client"

import type { CharacterData } from "../../index"
import { SelectControl } from "../controls/SelectControl"
import { ColorControl } from "../controls/ColorControl"

interface AppearancePanelProps {
  appearance: CharacterData["appearance"]
  updateCharacterData: (updates: Partial<CharacterData>) => void
}

export function AppearancePanel({ appearance, updateCharacterData }: AppearancePanelProps) {
  const updateAppearance = (key: keyof CharacterData["appearance"], value: number) => {
    updateCharacterData({ appearance: { ...appearance, [key]: value } })
  }

  const hairColors = [
    "#1a1a1a",
    "#2d2d2d",
    "#4a3728",
    "#6b4423",
    "#8b5a3c",
    "#a0522d",
    "#cd853f",
    "#daa520",
    "#f4a460",
    "#ffa07a",
    "#ff6347",
    "#dc143c",
    "#8b0000",
    "#4b0082",
    "#9370db",
    "#ba55d3",
  ]

  const eyeColors = [
    "#4169e1",
    "#1e90ff",
    "#87ceeb",
    "#00ced1",
    "#20b2aa",
    "#3cb371",
    "#228b22",
    "#808000",
    "#a0522d",
    "#8b4513",
    "#654321",
    "#2f4f4f",
    "#696969",
    "#708090",
    "#778899",
    "#000000",
  ]

  return (
    <div className="panel-section">
      <h3 className="panel-title">Aussehen</h3>
      <SelectControl
        label="Frisur"
        value={appearance.hairStyle}
        options={Array.from({ length: 38 }, (_, i) => ({ value: i, label: `Stil ${i}` }))}
        onChange={(value) => updateAppearance("hairStyle", value)}
      />
      <ColorControl
        label="Haarfarbe"
        value={appearance.hairColor}
        colors={hairColors}
        onChange={(value) => updateAppearance("hairColor", value)}
      />
      <ColorControl
        label="Augenfarbe"
        value={appearance.eyeColor}
        colors={eyeColors}
        onChange={(value) => updateAppearance("eyeColor", value)}
      />
      <SelectControl
        label="Hautton"
        value={appearance.skinTone}
        options={Array.from({ length: 12 }, (_, i) => ({ value: i, label: `Ton ${i}` }))}
        onChange={(value) => updateAppearance("skinTone", value)}
      />
      <SelectControl
        label="Teint"
        value={appearance.complexion}
        options={Array.from({ length: 12 }, (_, i) => ({ value: i, label: `${i}` }))}
        onChange={(value) => updateAppearance("complexion", value)}
      />
      <SelectControl
        label="Alterung"
        value={appearance.ageing}
        options={Array.from({ length: 15 }, (_, i) => ({ value: i, label: `${i}` }))}
        onChange={(value) => updateAppearance("ageing", value)}
      />
      <SelectControl
        label="Bart"
        value={appearance.beard}
        options={Array.from({ length: 29 }, (_, i) => ({ value: i, label: `Stil ${i}` }))}
        onChange={(value) => updateAppearance("beard", value)}
      />
      <ColorControl
        label="Bartfarbe"
        value={appearance.beardColor}
        colors={hairColors}
        onChange={(value) => updateAppearance("beardColor", value)}
      />
    </div>
  )
}
