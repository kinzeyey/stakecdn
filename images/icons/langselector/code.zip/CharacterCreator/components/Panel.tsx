import type { Step, CharacterData } from "../index"
import { GenderPanel } from "./panels/GenderPanel"
import { ParentsPanel } from "./panels/ParentsPanel"
import { FeaturesPanel } from "./panels/FeaturesPanel"
import { HeritagePanel } from "./panels/HeritagePanel"
import { AppearancePanel } from "./panels/AppearancePanel"

interface PanelProps {
  currentStep: Step
  characterData: CharacterData
  updateCharacterData: (updates: Partial<CharacterData>) => void
}

export function Panel({ currentStep, characterData, updateCharacterData }: PanelProps) {
  return (
    <div className="side-panel">
      <div className="panel-content">
        {currentStep === "genderParents" && (
          <>
            <GenderPanel gender={characterData.gender} updateCharacterData={updateCharacterData} />
            <div className="panel-divider" />
            <ParentsPanel parents={characterData.parents} updateCharacterData={updateCharacterData} />
          </>
        )}
        {currentStep === "features" && (
          <FeaturesPanel features={characterData.features} updateCharacterData={updateCharacterData} />
        )}
        {currentStep === "heritage" && (
          <HeritagePanel heritage={characterData.heritage} updateCharacterData={updateCharacterData} />
        )}
        {currentStep === "appearance" && (
          <AppearancePanel appearance={characterData.appearance} updateCharacterData={updateCharacterData} />
        )}
      </div>
    </div>
  )
}
