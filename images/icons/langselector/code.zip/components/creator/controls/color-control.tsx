"use client"

interface ColorControlProps {
  value: number
  onChange: (value: number) => void
  colors: string[]
}

export function ColorControl({ value, onChange, colors }: ColorControlProps) {
  return (
    <div className="flex items-center gap-[0.5vh] ml-auto">
      <div className="flex gap-[0.35vh] p-[0.2vh] max-w-[14vh] overflow-x-auto scrollbar-none">
        {colors.map((color, index) => (
          <button
            key={index}
            onClick={() => onChange(index)}
            className={`
              min-w-[1.7vh] h-[1.7vh] rounded-[0.25vh]
              transition-all
              ${value === index ? "ring-[0.2vh] ring-white" : "ring-[0.2vh] ring-transparent"}
            `}
            style={{ backgroundColor: color }}
          />
        ))}
      </div>
    </div>
  )
}
