"use client"

import type React from "react"

import { Slider } from "@/components/ui/slider"

interface RangeControlProps {
  value: number
  onChange: (value: number) => void
  min?: number
  max?: number
  leftIcon?: React.ReactNode
  rightIcon?: React.ReactNode
}

export function RangeControl({ value, onChange, min = 0, max = 100, leftIcon, rightIcon }: RangeControlProps) {
  return (
    <div className="flex items-center gap-[1vh] ml-auto">
      {leftIcon && (
        <div className="w-[1.5vh] h-[1.5vh] flex items-center opacity-25 pointer-events-none text-white">
          {leftIcon}
        </div>
      )}
      <Slider
        value={[value]}
        onValueChange={(values) => onChange(values[0])}
        min={min}
        max={max}
        step={1}
        className="w-[12vh]"
      />
      <span className="text-white text-[1.4vh] w-[4.5vh] text-right">{value}</span>
      {rightIcon && (
        <div className="w-[1.5vh] h-[1.5vh] flex items-center opacity-25 pointer-events-none text-white">
          {rightIcon}
        </div>
      )}
    </div>
  )
}
