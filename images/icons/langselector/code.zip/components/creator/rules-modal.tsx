"use client"

import { X } from "lucide-react"

interface RulesModalProps {
  onClose: () => void
}

export function RulesModal({ onClose }: RulesModalProps) {
  return (
    <div className="fixed inset-0 bg-[rgba(18,18,18,0.7)] flex items-center justify-center z-50">
      <div className="relative bg-[#f9f9f9] w-[49.63vh] rounded-[1vh] p-[7vh] max-h-[85vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute right-[4vh] top-[4vh] w-[2.5vh] h-[2.5vh] text-[#111] hover:opacity-70 transition-opacity"
        >
          <X className="w-full h-full" />
        </button>

        <h2 className="text-[1.75vh] font-bold text-[#111]">Character Creator Regeln</h2>

        <h3 className="text-[1.5vh] font-black text-[#111] mt-[2vh]">ALLGEMEINE REGELN</h3>
        <ul className="mt-[2vh] space-y-[0.5vh] ml-[1.5vh]">
          <li className="text-[1.25vh] font-medium text-[#111] list-image-[url('data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='7' height='7'%3E%3Crect width='7' height='7' rx='2' fill='%231e1e1e'/%3E%3C/svg%3E')]">
            Erstellen Sie einen realistischen Charakter
          </li>
          <li className="text-[1.25vh] font-medium text-[#111] list-image-[url('data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='7' height='7'%3E%3Crect width='7' height='7' rx='2' fill='%231e1e1e'/%3E%3C/svg%3E')]">
            Keine unangemessenen Namen oder Aussehen
          </li>
          <li className="text-[1.25vh] font-medium text-[#111] list-image-[url('data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='7' height='7'%3E%3Crect width='7' height='7' rx='2' fill='%231e1e1e'/%3E%3C/svg%3E')]">
            Respektieren Sie andere Spieler
          </li>
        </ul>

        <p className="text-[1.25vh] mt-[1vh] opacity-50 text-[#111]">
          Verstoß gegen diese Regeln kann zu Sanktionen führen.
        </p>

        <h3 className="text-[1.5vh] font-black text-[#111] mt-[2vh]">NAMENSRICHTLINIEN</h3>
        <ul className="mt-[2vh] space-y-[0.5vh] ml-[1.5vh]">
          <li className="text-[1.25vh] font-medium text-[#111] list-image-[url('data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='7' height='7'%3E%3Crect width='7' height='7' rx='2' fill='%231e1e1e'/%3E%3C/svg%3E')]">
            Verwenden Sie realistische Vor- und Nachnamen
          </li>
          <li className="text-[1.25vh] font-medium text-[#111] list-image-[url('data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='7' height='7'%3E%3Crect width='7' height='7' rx='2' fill='%231e1e1e'/%3E%3C/svg%3E')]">
            Keine Zahlen oder Sonderzeichen
          </li>
          <li className="text-[1.25vh] font-medium text-[#111] list-image-[url('data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='7' height='7'%3E%3Crect width='7' height='7' rx='2' fill='%231e1e1e'/%3E%3C/svg%3E')]">
            Keine prominenten Persönlichkeiten
          </li>
        </ul>

        <p className="text-[1.25vh] mt-[1vh] opacity-75 text-[#111]">Namen müssen authentisch und angemessen sein.</p>

        <p className="text-[1.5vh] font-black text-[#fc1f1f] mt-[2vh]">WICHTIG: VERSTÖSSE WERDEN BESTRAFT!</p>
      </div>
    </div>
  )
}
