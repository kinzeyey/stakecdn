"use client"

import { useState } from "react"
import { Eye, EyeOff } from "lucide-react"
import type { CharacterData } from "../character-creator"

interface FinishModalProps {
  characterData: CharacterData
  onClose: () => void
  onConfirm: () => void
  updateCharacterData: (updates: Partial<CharacterData>) => void
}

export function FinishModal({ characterData, onClose, onConfirm, updateCharacterData }: FinishModalProps) {
  const [showDate, setShowDate] = useState(false)

  return (
    <div className="fixed inset-0 bg-[rgba(18,18,18,0.7)] flex items-center justify-center z-50">
      <div className="bg-[rgba(18,18,18,0.95)] w-[40vh] rounded-[1vh] p-[3vh] backdrop-blur-md">
        <h2 className="text-white text-[2.5vh] uppercase font-black">Charakter erstellen</h2>

        <p className="text-[1.4vh] text-[rgba(255,255,255,0.5)] mt-[1vh]">
          Bitte geben Sie die persönlichen Daten Ihres Charakters ein.
        </p>

        <p className="text-[1.4vh] text-[rgba(255,255,255,0.75)] mt-[1.8vh]">
          Diese Informationen werden für die Registrierung verwendet.
        </p>

        <div className="mt-[2vh] space-y-[1vh]">
          <div className="h-[4.81vh] rounded-[0.5vh] overflow-hidden bg-[rgba(18,18,18,0.6)] flex items-center">
            <input
              type="text"
              placeholder="Vorname"
              value={characterData.firstName}
              onChange={(e) => updateCharacterData({ firstName: e.target.value })}
              className="w-full h-full px-[1.85vh] bg-transparent border-none outline-none text-white text-[1.3vh] font-medium placeholder:text-[rgba(255,255,255,0.3)]"
            />
          </div>

          <div className="h-[4.81vh] rounded-[0.5vh] overflow-hidden bg-[rgba(18,18,18,0.6)] flex items-center">
            <input
              type="text"
              placeholder="Nachname"
              value={characterData.lastName}
              onChange={(e) => updateCharacterData({ lastName: e.target.value })}
              className="w-full h-full px-[1.85vh] bg-transparent border-none outline-none text-white text-[1.3vh] font-medium placeholder:text-[rgba(255,255,255,0.3)]"
            />
          </div>

          <div className="h-[4.81vh] rounded-[0.5vh] overflow-hidden bg-[rgba(18,18,18,0.6)] flex items-center">
            <input
              type={showDate ? "date" : "text"}
              placeholder="Geburtsdatum (TT.MM.JJJJ)"
              value={characterData.dateOfBirth}
              onChange={(e) => updateCharacterData({ dateOfBirth: e.target.value })}
              onFocus={() => setShowDate(true)}
              className="w-full h-full px-[1.85vh] bg-transparent border-none outline-none text-white text-[1.3vh] font-medium placeholder:text-[rgba(255,255,255,0.3)]"
            />
            <button
              onClick={() => setShowDate(!showDate)}
              className="w-[1.75vh] h-[1.75vh] mr-[2vh] opacity-50 hover:opacity-100 transition-opacity"
            >
              {showDate ? (
                <EyeOff className="w-full h-full text-white" />
              ) : (
                <Eye className="w-full h-full text-white" />
              )}
            </button>
          </div>
        </div>

        <div className="mt-[2vh] flex gap-[0.65vh]">
          <button
            onClick={onClose}
            className="flex-1 h-[5vh] rounded-[0.65vh] bg-[rgba(255,255,255,0.05)] hover:bg-[rgba(255,255,255,0.1)] text-[rgba(255,255,255,0.5)] hover:text-white text-[1.3vh] transition-all"
          >
            Abbrechen
          </button>
          <button
            onClick={onConfirm}
            className="flex-1 h-[5vh] rounded-[0.65vh] bg-[rgba(255,255,255,0.05)] hover:bg-[oklch(0.65_0.22_285)] text-[rgba(255,255,255,0.5)] hover:text-white text-[1.3vh] transition-all"
          >
            Bestätigen
          </button>
        </div>
      </div>
    </div>
  )
}
