"use client"

import type React from "react"

import type { Step } from "../character-creator"
import { Users, Scan, Globe, Sparkles } from "lucide-react"

interface StepsProps {
  currentStep: Step
  onStepClick: (step: Step) => void
}

const steps: { id: Step; icon: React.ReactNode; title: string }[] = [
  { id: "genderParents", icon: <Users className="w-full h-full" />, title: "Geschlecht & Eltern" },
  { id: "features", icon: <Scan className="w-full h-full" />, title: "Gesichtszüge" },
  { id: "heritage", icon: <Globe className="w-full h-full" />, title: "Herkunft" },
  { id: "appearance", icon: <Sparkles className="w-full h-full" />, title: "Aussehen" },
]

export function Steps({ currentStep, onStepClick }: StepsProps) {
  return (
    <div className="absolute left-1/2 -translate-x-1/2 top-[2.5vh] flex gap-[1.35vh] z-10">
      {steps.map((step) => (
        <button
          key={step.id}
          onClick={() => onStepClick(step.id)}
          className={`
            relative w-[4.63vh] h-[4.63vh] rounded-full 
            flex items-center justify-center
            transition-all duration-200 ease-in-out
            group
            ${currentStep === step.id ? "bg-[#1aaff1]" : "bg-[rgba(18,18,18,0.8)] hover:bg-[#1aaff1]"}
          `}
        >
          <span className="flex items-center justify-center w-full h-full text-white">
            <div className="w-[1.5vh] h-[1.5vh]">{step.icon}</div>
          </span>
          <span
            className={`
            absolute bottom-[-3.7vh] whitespace-nowrap
            text-[1.5vh] font-medium text-white
            opacity-0 invisible group-hover:opacity-100 group-hover:visible
            transition-all duration-200 pointer-events-none
            drop-shadow-[0_0_3px_rgba(0,0,0,0.16)]
            ${currentStep === step.id ? "hidden" : ""}
          `}
          >
            {step.title}
          </span>
        </button>
      ))}
    </div>
  )
}
