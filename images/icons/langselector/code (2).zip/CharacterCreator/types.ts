export type Step = "genderParents" | "features" | "heritage" | "appearance"

export interface CharacterData {
  gender: number
  parents: {
    mother: number
    father: number
  }
  features: {
    face: number
    nose: number
    noseTilt: number
    eyebrows: number
    eyebrowHeight: number
    eyes: number
  }
  heritage: {
    fatherHeritage: number
    motherHeritage: number
    resemblance: number
  }
  appearance: {
    hairStyle: number
    hairColor: number
    eyeColor: number
    skinTone: number
    complexion: number
    ageing: number
    beard: number
    beardColor: number
  }
  firstName: string
  lastName: string
  dateOfBirth: string
}
