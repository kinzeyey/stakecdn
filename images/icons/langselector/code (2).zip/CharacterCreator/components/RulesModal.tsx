"use client"

import { X } from "lucide-react"

interface RulesModalProps {
  onClose: () => void
}

export function RulesModal({ onClose }: RulesModalProps) {
  return (
    <div className="cc-modal-overlay" onClick={onClose}>
      <div className="cc-modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="cc-modal-header">
          <h2 className="cc-modal-title">Regeln</h2>
          <button onClick={onClose} className="cc-modal-close">
            <X className="w-full h-full" />
          </button>
        </div>

        <div className="cc-modal-body">
          <div className="cc-rules-text">
            <p>Willkommen beim Character Creator!</p>
            <h3>Allgemeine Regeln:</h3>
            <ul>
              <li>Erstelle einen einzigartigen Charakter mit individuellen Eigenschaften</li>
              <li>Alle Anpassungen sind optional und können jederzeit geändert werden</li>
              <li>Nutze den Zufällig-Button für Inspiration</li>
              <li>Speichere deinen Charakter am Ende mit einem Namen</li>
            </ul>
            <h3>Anpassungsmöglichkeiten:</h3>
            <ul>
              <li>Geschlecht und Eltern auswählen</li>
              <li>Gesichtszüge detailliert anpassen</li>
              <li>Herkunft und Ähnlichkeit festlegen</li>
              <li>Aussehen wie Haare, Augen und Hautfarbe wählen</li>
            </ul>
          </div>
        </div>

        <div className="cc-modal-buttons">
          <button onClick={onClose} className="cc-modal-button cc-modal-button-primary">
            Verstanden
          </button>
        </div>
      </div>
    </div>
  )
}
