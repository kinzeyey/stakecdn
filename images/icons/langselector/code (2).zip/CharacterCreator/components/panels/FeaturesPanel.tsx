"use client"

import { SelectControl } from "../controls/SelectControl"
import { RangeControl } from "../controls/RangeControl"

interface FeaturesPanelProps {
  features: {
    face: number
    nose: number
    noseTilt: number
    eyebrows: number
    eyebrowHeight: number
    eyes: number
  }
  updateCharacterData: (updates: any) => void
}

export function FeaturesPanel({ features, updateCharacterData }: FeaturesPanelProps) {
  return (
    <>
      <div className="cc-panel-title">Gesichtszüge</div>

      <div className="cc-panel-section cc-panel-scrollable">
        <div className="cc-control-row">
          <span className="cc-control-label">Gesicht</span>
          <SelectControl
            value={features.face}
            onChange={(value) => updateCharacterData({ features: { ...features, face: value } })}
            max={20}
          />
        </div>
        <div className="cc-control-row">
          <span className="cc-control-label">Nase</span>
          <SelectControl
            value={features.nose}
            onChange={(value) => updateCharacterData({ features: { ...features, nose: value } })}
            max={20}
          />
        </div>
        <div className="cc-control-row">
          <span className="cc-control-label">Nasenneigung</span>
          <RangeControl
            value={features.noseTilt}
            onChange={(value) => updateCharacterData({ features: { ...features, noseTilt: value } })}
            min={0}
            max={100}
          />
        </div>
        <div className="cc-control-row">
          <span className="cc-control-label">Augenbrauen</span>
          <SelectControl
            value={features.eyebrows}
            onChange={(value) => updateCharacterData({ features: { ...features, eyebrows: value } })}
            max={33}
          />
        </div>
        <div className="cc-control-row">
          <span className="cc-control-label">Augenbrauenhöhe</span>
          <RangeControl
            value={features.eyebrowHeight}
            onChange={(value) => updateCharacterData({ features: { ...features, eyebrowHeight: value } })}
            min={0}
            max={100}
          />
        </div>
        <div className="cc-control-row">
          <span className="cc-control-label">Augen</span>
          <SelectControl
            value={features.eyes}
            onChange={(value) => updateCharacterData({ features: { ...features, eyes: value } })}
            max={31}
          />
        </div>
      </div>
    </>
  )
}
