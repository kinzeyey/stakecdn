"use client"

import { SelectControl } from "../controls/SelectControl"
import { RangeControl } from "../controls/RangeControl"

interface HeritagePanelProps {
  heritage: {
    fatherHeritage: number
    motherHeritage: number
    resemblance: number
  }
  updateCharacterData: (updates: any) => void
}

export function HeritagePanel({ heritage, updateCharacterData }: HeritagePanelProps) {
  return (
    <>
      <div className="cc-panel-title">Herkunft</div>

      <div className="cc-panel-section">
        <div className="cc-control-row">
          <span className="cc-control-label">Vater Herkunft</span>
          <SelectControl
            value={heritage.fatherHeritage}
            onChange={(value) => updateCharacterData({ heritage: { ...heritage, fatherHeritage: value } })}
            max={21}
          />
        </div>
        <div className="cc-control-row">
          <span className="cc-control-label">Mutter Herkunft</span>
          <SelectControl
            value={heritage.motherHeritage}
            onChange={(value) => updateCharacterData({ heritage: { ...heritage, motherHeritage: value } })}
            max={21}
          />
        </div>
        <div className="cc-control-row">
          <span className="cc-control-label">Ähnlichkeit</span>
          <RangeControl
            value={heritage.resemblance}
            onChange={(value) => updateCharacterData({ heritage: { ...heritage, resemblance: value } })}
            min={0}
            max={100}
          />
        </div>
      </div>
    </>
  )
}
