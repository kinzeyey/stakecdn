"use client"

import { SelectControl } from "../controls/SelectControl"

interface ParentsPanelProps {
  parents: { mother: number; father: number }
  updateCharacterData: (updates: any) => void
}

export function ParentsPanel({ parents, updateCharacterData }: ParentsPanelProps) {
  return (
    <>
      <div className="cc-panel-title">Eltern</div>

      <div className="cc-panel-image-container">
        <div className="cc-panel-image-bg" style={{ backgroundImage: "url('/silhouette-family-portrait.jpg')" }} />
        <div
          className="cc-panel-image-left"
          style={{ backgroundImage: "url('/woman-portrait-mother---parents-mother-.jpg')" }}
        />
        <div
          className="cc-panel-image-right"
          style={{ backgroundImage: "url('/man-portrait-father---parents-father-.jpg')" }}
        />
      </div>

      <div className="cc-panel-section">
        <div className="cc-control-row">
          <span className="cc-control-label">Mutter</span>
          <SelectControl
            value={parents.mother}
            onChange={(value) => updateCharacterData({ parents: { ...parents, mother: value } })}
            max={45}
          />
        </div>
        <div className="cc-control-row">
          <span className="cc-control-label">Vater</span>
          <SelectControl
            value={parents.father}
            onChange={(value) => updateCharacterData({ parents: { ...parents, father: value } })}
            max={45}
          />
        </div>
      </div>
    </>
  )
}
