"use client"

import { RangeControl } from "../controls/RangeControl"
import { User, UserRound } from "lucide-react"

interface GenderPanelProps {
  gender: number
  updateCharacterData: (updates: any) => void
}

export function GenderPanel({ gender, updateCharacterData }: GenderPanelProps) {
  return (
    <>
      <div className="cc-panel-title">Geschlecht</div>

      <div className="cc-panel-section">
        <div className="cc-control-row">
          <span className="cc-control-label">Geschlecht</span>
          <RangeControl
            value={gender}
            onChange={(value) => updateCharacterData({ gender: value })}
            min={0}
            max={100}
            leftIcon={<User className="w-full h-full" />}
            rightIcon={<UserRound className="w-full h-full" />}
          />
        </div>
      </div>
    </>
  )
}
