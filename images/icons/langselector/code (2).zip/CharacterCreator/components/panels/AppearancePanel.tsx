"use client"

import { SelectControl } from "../controls/SelectControl"
import { ColorControl } from "../controls/ColorControl"

interface AppearancePanelProps {
  appearance: {
    hairStyle: number
    hairColor: number
    eyeColor: number
    skinTone: number
    complexion: number
    ageing: number
    beard: number
    beardColor: number
  }
  updateCharacterData: (updates: any) => void
}

const hairColors = [
  "#000000",
  "#1a1a1a",
  "#2d2d2d",
  "#3d3d3d",
  "#4a4a4a",
  "#5a5a5a",
  "#6b6b6b",
  "#7c7c7c",
  "#8c8c8c",
  "#9d9d9d",
  "#3d2314",
  "#4d2e1a",
  "#5d3920",
  "#6d4426",
  "#7d4f2c",
  "#8d5a32",
  "#9d6538",
  "#ad703e",
  "#bd7b44",
  "#cd864a",
]

const eyeColors = [
  "#4a3728",
  "#5a4738",
  "#6a5748",
  "#7a6758",
  "#2a4a5a",
  "#3a5a6a",
  "#4a6a7a",
  "#5a7a8a",
  "#2a5a3a",
  "#3a6a4a",
  "#4a7a5a",
  "#5a8a6a",
  "#5a4a2a",
  "#6a5a3a",
  "#7a6a4a",
  "#8a7a5a",
]

export function AppearancePanel({ appearance, updateCharacterData }: AppearancePanelProps) {
  return (
    <>
      <div className="cc-panel-title">Aussehen</div>

      <div className="cc-panel-section cc-panel-scrollable">
        <div className="cc-control-row">
          <span className="cc-control-label">Frisur</span>
          <SelectControl
            value={appearance.hairStyle}
            onChange={(value) => updateCharacterData({ appearance: { ...appearance, hairStyle: value } })}
            max={37}
          />
        </div>
        <div className="cc-control-column">
          <span className="cc-control-label">Haarfarbe</span>
          <ColorControl
            value={appearance.hairColor}
            onChange={(value) => updateCharacterData({ appearance: { ...appearance, hairColor: value } })}
            colors={hairColors}
          />
        </div>
        <div className="cc-control-column">
          <span className="cc-control-label">Augenfarbe</span>
          <ColorControl
            value={appearance.eyeColor}
            onChange={(value) => updateCharacterData({ appearance: { ...appearance, eyeColor: value } })}
            colors={eyeColors}
          />
        </div>
        <div className="cc-control-row">
          <span className="cc-control-label">Hautton</span>
          <SelectControl
            value={appearance.skinTone}
            onChange={(value) => updateCharacterData({ appearance: { ...appearance, skinTone: value } })}
            max={11}
          />
        </div>
        <div className="cc-control-row">
          <span className="cc-control-label">Teint</span>
          <SelectControl
            value={appearance.complexion}
            onChange={(value) => updateCharacterData({ appearance: { ...appearance, complexion: value } })}
            max={11}
          />
        </div>
        <div className="cc-control-row">
          <span className="cc-control-label">Alterung</span>
          <SelectControl
            value={appearance.ageing}
            onChange={(value) => updateCharacterData({ appearance: { ...appearance, ageing: value } })}
            max={14}
          />
        </div>
        <div className="cc-control-row">
          <span className="cc-control-label">Bart</span>
          <SelectControl
            value={appearance.beard}
            onChange={(value) => updateCharacterData({ appearance: { ...appearance, beard: value } })}
            max={28}
          />
        </div>
        <div className="cc-control-column">
          <span className="cc-control-label">Bartfarbe</span>
          <ColorControl
            value={appearance.beardColor}
            onChange={(value) => updateCharacterData({ appearance: { ...appearance, beardColor: value } })}
            colors={hairColors}
          />
        </div>
      </div>
    </>
  )
}
