"use client"

import { X } from "lucide-react"
import type { CharacterData } from "../types"

interface FinishModalProps {
  characterData: CharacterData
  onClose: () => void
  onConfirm: () => void
  updateCharacterData: (updates: Partial<CharacterData>) => void
}

export function FinishModal({ characterData, onClose, onConfirm, updateCharacterData }: FinishModalProps) {
  return (
    <div className="cc-modal-overlay" onClick={onClose}>
      <div className="cc-modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="cc-modal-header">
          <h2 className="cc-modal-title">Charakter fertigstellen</h2>
          <button onClick={onClose} className="cc-modal-close">
            <X className="w-full h-full" />
          </button>
        </div>

        <div className="cc-modal-body">
          <div className="cc-input-group">
            <label className="cc-input-label">Vorname</label>
            <input
              type="text"
              value={characterData.firstName}
              onChange={(e) => updateCharacterData({ firstName: e.target.value })}
              className="cc-input-field"
              placeholder="Gib deinen Vornamen ein..."
            />
          </div>

          <div className="cc-input-group">
            <label className="cc-input-label">Nachname</label>
            <input
              type="text"
              value={characterData.lastName}
              onChange={(e) => updateCharacterData({ lastName: e.target.value })}
              className="cc-input-field"
              placeholder="Gib deinen Nachnamen ein..."
            />
          </div>

          <div className="cc-input-group">
            <label className="cc-input-label">Geburtsdatum</label>
            <input
              type="date"
              value={characterData.dateOfBirth}
              onChange={(e) => updateCharacterData({ dateOfBirth: e.target.value })}
              className="cc-input-field"
            />
          </div>
        </div>

        <div className="cc-modal-buttons">
          <button onClick={onClose} className="cc-modal-button cc-modal-button-secondary">
            Abbrechen
          </button>
          <button onClick={onConfirm} className="cc-modal-button cc-modal-button-primary">
            Bestätigen
          </button>
        </div>
      </div>
    </div>
  )
}
