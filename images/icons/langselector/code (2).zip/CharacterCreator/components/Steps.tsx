"use client"

import type React from "react"

import type { Step } from "../types"
import { Users, Scan, Globe, Sparkles } from "lucide-react"

interface StepsProps {
  currentStep: Step
  onStepClick: (step: Step) => void
}

const steps: { id: Step; icon: React.ReactNode; title: string }[] = [
  { id: "genderParents", icon: <Users className="w-full h-full" />, title: "Geschlecht & Eltern" },
  { id: "features", icon: <Scan className="w-full h-full" />, title: "Gesichtszüge" },
  { id: "heritage", icon: <Globe className="w-full h-full" />, title: "Herkunft" },
  { id: "appearance", icon: <Sparkles className="w-full h-full" />, title: "Aussehen" },
]

export function Steps({ currentStep, onStepClick }: StepsProps) {
  return (
    <div className="cc-steps-container">
      {steps.map((step) => (
        <button
          key={step.id}
          onClick={() => onStepClick(step.id)}
          className={`cc-step-button ${currentStep === step.id ? "cc-step-active" : ""}`}
        >
          <span className="cc-step-icon">
            <div className="cc-step-icon-inner">{step.icon}</div>
          </span>
          <span className={`cc-step-tooltip ${currentStep === step.id ? "cc-step-tooltip-hidden" : ""}`}>
            {step.title}
          </span>
        </button>
      ))}
    </div>
  )
}
