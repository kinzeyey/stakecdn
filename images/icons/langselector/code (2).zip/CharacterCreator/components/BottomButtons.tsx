"use client"

import { Shuffle, RotateCcw, Check, FileText } from "lucide-react"

interface BottomButtonsProps {
  onRandomize: () => void
  onReset: () => void
  onFinish: () => void
  onRules: () => void
}

export function BottomButtons({ onRandomize, onReset, onFinish, onRules }: BottomButtonsProps) {
  return (
    <div className="cc-bottom-buttons">
      <button onClick={onRandomize} className="cc-bottom-button">
        <Shuffle className="cc-bottom-button-icon" />
        <span className="cc-bottom-button-tooltip">Zufällig</span>
      </button>

      <button onClick={onReset} className="cc-bottom-button">
        <RotateCcw className="cc-bottom-button-icon" />
        <span className="cc-bottom-button-tooltip">Zurücksetzen</span>
      </button>

      <button onClick={onFinish} className="cc-bottom-button">
        <Check className="cc-bottom-button-icon" />
        <span className="cc-bottom-button-tooltip">Fertigstellen</span>
      </button>

      <button onClick={onRules} className="cc-bottom-button">
        <FileText className="cc-bottom-button-icon" />
        <span className="cc-bottom-button-tooltip">Regeln</span>
      </button>
    </div>
  )
}
