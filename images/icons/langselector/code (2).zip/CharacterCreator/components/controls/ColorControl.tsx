"use client"

interface ColorControlProps {
  value: number
  onChange: (value: number) => void
  colors: string[]
}

export function ColorControl({ value, onChange, colors }: ColorControlProps) {
  return (
    <div className="cc-color-grid">
      {colors.map((color, index) => (
        <button
          key={index}
          onClick={() => onChange(index)}
          className={`cc-color-button ${value === index ? "cc-color-active" : ""}`}
          style={{ backgroundColor: color }}
        />
      ))}
    </div>
  )
}
