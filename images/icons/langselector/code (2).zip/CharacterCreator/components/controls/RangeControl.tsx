"use client"

import type React from "react"

interface RangeControlProps {
  value: number
  onChange: (value: number) => void
  min: number
  max: number
  leftIcon?: React.ReactNode
  rightIcon?: React.ReactNode
}

export function RangeControl({ value, onChange, min, max, leftIcon, rightIcon }: RangeControlProps) {
  return (
    <div className="cc-range-control">
      {leftIcon && <div className="cc-range-icon">{leftIcon}</div>}
      <input
        type="range"
        min={min}
        max={max}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="cc-range-slider"
      />
      {rightIcon && <div className="cc-range-icon">{rightIcon}</div>}
      <span className="cc-range-value">{value}</span>
    </div>
  )
}
