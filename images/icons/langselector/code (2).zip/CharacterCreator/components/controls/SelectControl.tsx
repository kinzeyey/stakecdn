"use client"

import { ChevronLeft, ChevronRight } from "lucide-react"

interface SelectControlProps {
  value: number
  onChange: (value: number) => void
  max: number
  min?: number
}

export function SelectControl({ value, onChange, max, min = 0 }: SelectControlProps) {
  const handlePrevious = () => {
    if (value > min) onChange(value - 1)
  }

  const handleNext = () => {
    if (value < max) onChange(value + 1)
  }

  return (
    <div className="cc-select-control">
      <button onClick={handlePrevious} disabled={value <= min} className="cc-select-button">
        <ChevronLeft className="cc-select-icon" />
      </button>
      <span className="cc-select-value">{value}</span>
      <button onClick={handleNext} disabled={value >= max} className="cc-select-button">
        <ChevronRight className="cc-select-icon" />
      </button>
    </div>
  )
}
