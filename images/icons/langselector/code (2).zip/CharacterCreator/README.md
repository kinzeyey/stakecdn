# Character Creator Component

Ein vollständig eigenständiger Character Creator für React/Vite Projekte.

## Installation

1. Kopiere den gesamten `CharacterCreator` Ordner in dein Projekt:
   \`\`\`
   C:\Users\User\Desktop\Stake\stakepvp\game\PVP\resources\[stake]\stake\src\components\charactercreator
   \`\`\`

2. Installiere die einzige Dependency:
   \`\`\`bash
   npm install lucide-react
   \`\`\`

## Verwendung

\`\`\`tsx
import { CharacterCreator } from './components/charactercreator'

function App() {
  return (
    <div style={{ width: '100vw', height: '100vh' }}>
      <CharacterCreator />
    </div>
  )
}
\`\`\`

## Struktur

\`\`\`
CharacterCreator/
├── index.tsx              # Hauptkomponente
├── types.ts               # TypeScript Definitionen
├── styles.css             # Alle Styles
├── components/
│   ├── Steps.tsx          # Steps Navigation
│   ├── Panel.tsx          # Side Panel Container
│   ├── BottomButtons.tsx  # Bottom Action Buttons
│   ├── FinishModal.tsx    # Finish Modal
│   ├── RulesModal.tsx     # Rules Modal
│   ├── panels/
│   │   ├── GenderPanel.tsx
│   │   ├── ParentsPanel.tsx
│   │   ├── FeaturesPanel.tsx
│   │   ├── HeritagePanel.tsx
│   │   └── AppearancePanel.tsx
│   └── controls/
│       ├── SelectControl.tsx
│       ├── RangeControl.tsx
│       └── ColorControl.tsx
└── README.md
\`\`\`

## Features

- 4 Steps: Geschlecht & Eltern, Gesichtszüge, Herkunft, Aussehen
- Verschiedene Controls: Select, Range Slider, Color Picker
- Modal Dialoge für Fertigstellung und Regeln
- Vollständig responsive
- Dark Theme mit #1aaff1 Akzentfarbe
- Alle Styles in einer CSS Datei
- Keine externen Dependencies außer lucide-react

## Anpassung

Die Akzentfarbe kann in `styles.css` geändert werden (suche nach `#1aaff1`).

## Character Data

Die Komponente gibt beim Fertigstellen ein `CharacterData` Objekt zurück:

\`\`\`typescript
{
  gender: number,
  parents: { mother: number, father: number },
  features: { face, nose, noseTilt, eyebrows, eyebrowHeight, eyes },
  heritage: { fatherHeritage, motherHeritage, resemblance },
  appearance: { hairStyle, hairColor, eyeColor, skinTone, complexion, ageing, beard, beardColor },
  firstName: string,
  lastName: string,
  dateOfBirth: string
}
