"use client"

import { useState } from "react"
import { Steps } from "./creator/steps"
import { Panel } from "./creator/panel"
import { BottomButtons } from "./creator/bottom-buttons"
import { FinishModal } from "./creator/finish-modal"
import { RulesModal } from "./creator/rules-modal"

export type Step = "genderParents" | "features" | "heritage" | "appearance"

export interface CharacterData {
  gender: number // 0-100, 0=female, 100=male
  parents: {
    mother: number
    father: number
  }
  features: {
    face: number
    nose: number
    noseTilt: number
    eyebrows: number
    eyebrowHeight: number
    eyes: number
  }
  heritage: {
    fatherHeritage: number
    motherHeritage: number
    resemblance: number
  }
  appearance: {
    hairStyle: number
    hairColor: number
    eyeColor: number
    skinTone: number
    complexion: number
    ageing: number
    beard: number
    beardColor: number
  }
  firstName: string
  lastName: string
  dateOfBirth: string
}

const initialCharacterData: CharacterData = {
  gender: 50,
  parents: { mother: 0, father: 0 },
  features: {
    face: 0,
    nose: 0,
    noseTilt: 50,
    eyebrows: 0,
    eyebrowHeight: 50,
    eyes: 0,
  },
  heritage: {
    fatherHeritage: 0,
    motherHeritage: 0,
    resemblance: 50,
  },
  appearance: {
    hairStyle: 0,
    hairColor: 0,
    eyeColor: 0,
    skinTone: 0,
    complexion: 0,
    ageing: 0,
    beard: 0,
    beardColor: 0,
  },
  firstName: "",
  lastName: "",
  dateOfBirth: "",
}

export function CharacterCreator() {
  const [currentStep, setCurrentStep] = useState<Step>("genderParents")
  const [characterData, setCharacterData] = useState<CharacterData>(initialCharacterData)
  const [showFinishModal, setShowFinishModal] = useState(false)
  const [showRulesModal, setShowRulesModal] = useState(false)

  const updateCharacterData = (updates: Partial<CharacterData>) => {
    setCharacterData((prev) => ({ ...prev, ...updates }))
  }

  const handleRandomize = () => {
    // Randomize all values
    setCharacterData({
      gender: Math.floor(Math.random() * 101),
      parents: {
        mother: Math.floor(Math.random() * 46),
        father: Math.floor(Math.random() * 46),
      },
      features: {
        face: Math.floor(Math.random() * 21),
        nose: Math.floor(Math.random() * 21),
        noseTilt: Math.floor(Math.random() * 101),
        eyebrows: Math.floor(Math.random() * 34),
        eyebrowHeight: Math.floor(Math.random() * 101),
        eyes: Math.floor(Math.random() * 32),
      },
      heritage: {
        fatherHeritage: Math.floor(Math.random() * 22),
        motherHeritage: Math.floor(Math.random() * 22),
        resemblance: Math.floor(Math.random() * 101),
      },
      appearance: {
        hairStyle: Math.floor(Math.random() * 38),
        hairColor: Math.floor(Math.random() * 64),
        eyeColor: Math.floor(Math.random() * 32),
        skinTone: Math.floor(Math.random() * 12),
        complexion: Math.floor(Math.random() * 12),
        ageing: Math.floor(Math.random() * 15),
        beard: Math.floor(Math.random() * 29),
        beardColor: Math.floor(Math.random() * 64),
      },
      firstName: characterData.firstName,
      lastName: characterData.lastName,
      dateOfBirth: characterData.dateOfBirth,
    })
  }

  const handleReset = () => {
    setCharacterData(initialCharacterData)
  }

  const handleFinish = () => {
    setShowFinishModal(true)
  }

  return (
    <>
      <Steps currentStep={currentStep} onStepClick={setCurrentStep} />

      <Panel currentStep={currentStep} characterData={characterData} updateCharacterData={updateCharacterData} />

      <BottomButtons
        onRandomize={handleRandomize}
        onReset={handleReset}
        onFinish={handleFinish}
        onRules={() => setShowRulesModal(true)}
      />

      {showFinishModal && (
        <FinishModal
          characterData={characterData}
          onClose={() => setShowFinishModal(false)}
          onConfirm={() => {
            console.log("Character created:", characterData)
            setShowFinishModal(false)
          }}
          updateCharacterData={updateCharacterData}
        />
      )}

      {showRulesModal && <RulesModal onClose={() => setShowRulesModal(false)} />}
    </>
  )
}
