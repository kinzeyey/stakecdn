"use client"
import { CharacterCreator } from "@/components/character-creator"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-[#0a0a0a] relative overflow-hidden">
      <CharacterCreator />
    </div>
  )
}
