"use client"

import { ChevronLeft, ChevronRight } from "lucide-react"

interface SelectControlProps {
  value: number
  onChange: (value: number) => void
  max: number
  min?: number
}

export function SelectControl({ value, onChange, max, min = 0 }: SelectControlProps) {
  const handlePrevious = () => {
    if (value > min) onChange(value - 1)
  }

  const handleNext = () => {
    if (value < max) onChange(value + 1)
  }

  return (
    <div className="flex items-center gap-[1vh] ml-auto">
      <button
        onClick={handlePrevious}
        disabled={value <= min}
        className="w-[2.13vh] h-[2.13vh] rounded-[0.28vh] bg-[rgba(255,255,255,0.05)] hover:bg-[rgba(255,255,255,0.1)] transition-all disabled:opacity-30 disabled:cursor-not-allowed flex items-center justify-center"
      >
        <ChevronLeft className="w-[0.93vh] h-[0.93vh] text-white" />
      </button>
      <span className="text-white font-medium text-[1.3vh] w-[11.94vh] text-center">{value}</span>
      <button
        onClick={handleNext}
        disabled={value >= max}
        className="w-[2.13vh] h-[2.13vh] rounded-[0.28vh] bg-[rgba(255,255,255,0.05)] hover:bg-[rgba(255,255,255,0.1)] transition-all disabled:opacity-30 disabled:cursor-not-allowed flex items-center justify-center"
      >
        <ChevronRight className="w-[0.93vh] h-[0.93vh] text-white" />
      </button>
    </div>
  )
}
