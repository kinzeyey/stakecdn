"use client"

import { SelectControl } from "../controls/select-control"

interface ParentsPanelProps {
  parents: { mother: number; father: number }
  updateCharacterData: (updates: any) => void
}

export function ParentsPanel({ parents, updateCharacterData }: ParentsPanelProps) {
  return (
    <>
      <div className="text-white uppercase text-[1.8vh] font-medium mt-[2.2vh] mx-[2.75vh] mb-[1.85vh]">Eltern</div>

      <div className="relative h-[23vh] mx-[2.75vh] mb-[1.75vh] overflow-hidden rounded-[1vh]">
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat grayscale blur-[2px]"
          style={{
            backgroundImage: "url('/silhouette-family-portrait.jpg')",
          }}
        />
        <div
          className="absolute bottom-0 left-[2vh] w-[22vh] h-[22vh] bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url('/woman-portrait-mother---parents-mother-.jpg')`,
          }}
        />
        <div
          className="absolute bottom-0 right-[1vh] w-[22vh] h-[22vh] bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url('/man-portrait-father---parents-father-.jpg')`,
          }}
        />
      </div>

      <div className="px-[2.75vh] pb-[2.75vh] space-y-[0.5vh]">
        <div className="flex items-center justify-between bg-[rgba(18,18,18,0.6)] hover:bg-[rgba(0,0,0,0.6)] transition-all rounded-[0.65vh] h-[4.7vh] px-[1.75vh]">
          <span className="text-white text-[1.35vh]">Mutter</span>
          <SelectControl
            value={parents.mother}
            onChange={(value) => updateCharacterData({ parents: { ...parents, mother: value } })}
            max={45}
          />
        </div>
        <div className="flex items-center justify-between bg-[rgba(18,18,18,0.6)] hover:bg-[rgba(0,0,0,0.6)] transition-all rounded-[0.65vh] h-[4.7vh] px-[1.75vh]">
          <span className="text-white text-[1.35vh]">Vater</span>
          <SelectControl
            value={parents.father}
            onChange={(value) => updateCharacterData({ parents: { ...parents, father: value } })}
            max={45}
          />
        </div>
      </div>
    </>
  )
}
