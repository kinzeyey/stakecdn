"use client"

import { RangeControl } from "../controls/range-control"
import { User, UserRound } from "lucide-react"

interface GenderPanelProps {
  gender: number
  updateCharacterData: (updates: any) => void
}

export function GenderPanel({ gender, updateCharacterData }: GenderPanelProps) {
  return (
    <>
      <div className="text-white uppercase text-[1.8vh] font-medium mt-[2.2vh] mx-[2.75vh] mb-[1.85vh]">Geschlecht</div>

      <div className="px-[2.75vh] pb-[2.75vh]">
        <div className="flex items-center justify-between bg-[rgba(18,18,18,0.6)] hover:bg-[rgba(0,0,0,0.6)] transition-all rounded-[0.65vh] h-[4.7vh] px-[1.75vh]">
          <span className="text-white text-[1.35vh]">Geschlecht</span>
          <RangeControl
            value={gender}
            onChange={(value) => updateCharacterData({ gender: value })}
            min={0}
            max={100}
            leftIcon={<User className="w-full h-full" />}
            rightIcon={<UserRound className="w-full h-full" />}
          />
        </div>
      </div>
    </>
  )
}
