"use client"

import { SelectControl } from "../controls/select-control"
import { ColorControl } from "../controls/color-control"

interface AppearancePanelProps {
  appearance: {
    hairStyle: number
    hairColor: number
    eyeColor: number
    skinTone: number
    complexion: number
    ageing: number
    beard: number
    beardColor: number
  }
  updateCharacterData: (updates: any) => void
}

const hairColors = [
  "#1a1a1a",
  "#2b2420",
  "#3d2f28",
  "#4a3728",
  "#5c4033",
  "#6f4e37",
  "#8b5a3c",
  "#a0826d",
  "#bc9862",
  "#d4af37",
  "#e5c78f",
  "#f5deb3",
  "#f0e68c",
  "#ffd700",
  "#ff8c00",
  "#ff6347",
]

const eyeColors = [
  "#1c3a5e",
  "#2e5984",
  "#4682b4",
  "#5f9ea0",
  "#87ceeb",
  "#228b22",
  "#32cd32",
  "#90ee90",
  "#8b4513",
  "#a0522d",
  "#d2691e",
  "#808080",
  "#a9a9a9",
  "#c0c0c0",
]

const skinTones = [
  "#fef5e7",
  "#f8e5d0",
  "#f3d5b5",
  "#ecc9a6",
  "#e0b897",
  "#d4a574",
  "#c49465",
  "#b07f5a",
  "#9e6b4d",
  "#8d5841",
  "#6d4635",
  "#4a2f1f",
]

export function AppearancePanel({ appearance, updateCharacterData }: AppearancePanelProps) {
  const updateAppearance = (key: string, value: number) => {
    updateCharacterData({ appearance: { ...appearance, [key]: value } })
  }

  return (
    <>
      <div className="text-white uppercase text-[1.8vh] font-medium mt-[2.2vh] mx-[2.75vh] mb-[1.85vh]">Aussehen</div>

      <div className="px-[2.75vh] pb-[2.75vh] space-y-[0.5vh] max-h-[65vh] overflow-y-auto scrollbar-thin">
        <div className="flex items-center justify-between bg-[rgba(18,18,18,0.6)] hover:bg-[rgba(0,0,0,0.6)] transition-all rounded-[0.65vh] h-[4.7vh] px-[1.75vh]">
          <span className="text-white text-[1.35vh]">Frisur</span>
          <SelectControl value={appearance.hairStyle} onChange={(v) => updateAppearance("hairStyle", v)} max={37} />
        </div>
        <div className="flex items-center justify-between bg-[rgba(18,18,18,0.6)] hover:bg-[rgba(0,0,0,0.6)] transition-all rounded-[0.65vh] h-[4.7vh] px-[1.75vh]">
          <span className="text-white text-[1.35vh]">Haarfarbe</span>
          <ColorControl
            value={appearance.hairColor}
            onChange={(v) => updateAppearance("hairColor", v)}
            colors={hairColors}
          />
        </div>
        <div className="flex items-center justify-between bg-[rgba(18,18,18,0.6)] hover:bg-[rgba(0,0,0,0.6)] transition-all rounded-[0.65vh] h-[4.7vh] px-[1.75vh]">
          <span className="text-white text-[1.35vh]">Augenfarbe</span>
          <ColorControl
            value={appearance.eyeColor}
            onChange={(v) => updateAppearance("eyeColor", v)}
            colors={eyeColors}
          />
        </div>
        <div className="flex items-center justify-between bg-[rgba(18,18,18,0.6)] hover:bg-[rgba(0,0,0,0.6)] transition-all rounded-[0.65vh] h-[4.7vh] px-[1.75vh]">
          <span className="text-white text-[1.35vh]">Hautton</span>
          <ColorControl
            value={appearance.skinTone}
            onChange={(v) => updateAppearance("skinTone", v)}
            colors={skinTones}
          />
        </div>
        <div className="flex items-center justify-between bg-[rgba(18,18,18,0.6)] hover:bg-[rgba(0,0,0,0.6)] transition-all rounded-[0.65vh] h-[4.7vh] px-[1.75vh]">
          <span className="text-white text-[1.35vh]">Hautbild</span>
          <SelectControl value={appearance.complexion} onChange={(v) => updateAppearance("complexion", v)} max={11} />
        </div>
        <div className="flex items-center justify-between bg-[rgba(18,18,18,0.6)] hover:bg-[rgba(0,0,0,0.6)] transition-all rounded-[0.65vh] h-[4.7vh] px-[1.75vh]">
          <span className="text-white text-[1.35vh]">Alterung</span>
          <SelectControl value={appearance.ageing} onChange={(v) => updateAppearance("ageing", v)} max={14} />
        </div>
        <div className="flex items-center justify-between bg-[rgba(18,18,18,0.6)] hover:bg-[rgba(0,0,0,0.6)] transition-all rounded-[0.65vh] h-[4.7vh] px-[1.75vh]">
          <span className="text-white text-[1.35vh]">Bart</span>
          <SelectControl value={appearance.beard} onChange={(v) => updateAppearance("beard", v)} max={28} />
        </div>
        <div className="flex items-center justify-between bg-[rgba(18,18,18,0.6)] hover:bg-[rgba(0,0,0,0.6)] transition-all rounded-[0.65vh] h-[4.7vh] px-[1.75vh]">
          <span className="text-white text-[1.35vh]">Bartfarbe</span>
          <ColorControl
            value={appearance.beardColor}
            onChange={(v) => updateAppearance("beardColor", v)}
            colors={hairColors}
          />
        </div>
      </div>
    </>
  )
}
