"use client"

import { SelectControl } from "../controls/select-control"
import { RangeControl } from "../controls/range-control"

interface FeaturesPanelProps {
  features: {
    face: number
    nose: number
    noseTilt: number
    eyebrows: number
    eyebrowHeight: number
    eyes: number
  }
  updateCharacterData: (updates: any) => void
}

export function FeaturesPanel({ features, updateCharacterData }: FeaturesPanelProps) {
  const updateFeature = (key: string, value: number) => {
    updateCharacterData({ features: { ...features, [key]: value } })
  }

  return (
    <>
      <div className="text-white uppercase text-[1.8vh] font-medium mt-[2.2vh] mx-[2.75vh] mb-[1.85vh]">
        Gesichtszüge
      </div>

      <div className="px-[2.75vh] pb-[2.75vh] space-y-[0.5vh] max-h-[65vh] overflow-y-auto scrollbar-thin">
        <div className="flex items-center justify-between bg-[rgba(18,18,18,0.6)] hover:bg-[rgba(0,0,0,0.6)] transition-all rounded-[0.65vh] h-[4.7vh] px-[1.75vh]">
          <span className="text-white text-[1.35vh]">Gesicht</span>
          <SelectControl value={features.face} onChange={(v) => updateFeature("face", v)} max={20} />
        </div>
        <div className="flex items-center justify-between bg-[rgba(18,18,18,0.6)] hover:bg-[rgba(0,0,0,0.6)] transition-all rounded-[0.65vh] h-[4.7vh] px-[1.75vh]">
          <span className="text-white text-[1.35vh]">Nase</span>
          <SelectControl value={features.nose} onChange={(v) => updateFeature("nose", v)} max={20} />
        </div>
        <div className="flex items-center justify-between bg-[rgba(18,18,18,0.6)] hover:bg-[rgba(0,0,0,0.6)] transition-all rounded-[0.65vh] h-[4.7vh] px-[1.75vh]">
          <span className="text-white text-[1.35vh]">Nasenneigung</span>
          <RangeControl value={features.noseTilt} onChange={(v) => updateFeature("noseTilt", v)} min={0} max={100} />
        </div>
        <div className="flex items-center justify-between bg-[rgba(18,18,18,0.6)] hover:bg-[rgba(0,0,0,0.6)] transition-all rounded-[0.65vh] h-[4.7vh] px-[1.75vh]">
          <span className="text-white text-[1.35vh]">Augenbrauen</span>
          <SelectControl value={features.eyebrows} onChange={(v) => updateFeature("eyebrows", v)} max={33} />
        </div>
        <div className="flex items-center justify-between bg-[rgba(18,18,18,0.6)] hover:bg-[rgba(0,0,0,0.6)] transition-all rounded-[0.65vh] h-[4.7vh] px-[1.75vh]">
          <span className="text-white text-[1.35vh]">Augenbrauenhöhe</span>
          <RangeControl
            value={features.eyebrowHeight}
            onChange={(v) => updateFeature("eyebrowHeight", v)}
            min={0}
            max={100}
          />
        </div>
        <div className="flex items-center justify-between bg-[rgba(18,18,18,0.6)] hover:bg-[rgba(0,0,0,0.6)] transition-all rounded-[0.65vh] h-[4.7vh] px-[1.75vh]">
          <span className="text-white text-[1.35vh]">Augen</span>
          <SelectControl value={features.eyes} onChange={(v) => updateFeature("eyes", v)} max={31} />
        </div>
      </div>
    </>
  )
}
