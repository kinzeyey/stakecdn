"use client"

import { Shuffle, RotateCcw, Check, FileText } from "lucide-react"

interface BottomButtonsProps {
  onRandomize: () => void
  onReset: () => void
  onFinish: () => void
  onRules: () => void
}

export function BottomButtons({ onRandomize, onReset, onFinish, onRules }: BottomButtonsProps) {
  return (
    <div className="absolute left-1/2 -translate-x-1/2 bottom-[2vh] flex gap-[1.75vh] z-10">
      <button
        onClick={onRandomize}
        className="relative w-[6.94vh] h-[6.94vh] bg-[rgba(18,18,18,0.5)] hover:bg-[#1aaff1] rounded-full flex items-center justify-center transition-all duration-200 group"
      >
        <Shuffle className="w-[1.75vh] h-[1.75vh] text-white" />
        <span className="absolute top-[-3.24vh] whitespace-nowrap text-[1.5vh] font-medium text-white opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all pointer-events-none drop-shadow-[0_0_3px_rgba(0,0,0,0.16)]">
          Zufällig
        </span>
      </button>

      <button
        onClick={onReset}
        className="relative w-[6.94vh] h-[6.94vh] bg-[rgba(18,18,18,0.5)] hover:bg-[#1aaff1] rounded-full flex items-center justify-center transition-all duration-200 group"
      >
        <RotateCcw className="w-[1.75vh] h-[1.75vh] text-white" />
        <span className="absolute top-[-3.24vh] whitespace-nowrap text-[1.5vh] font-medium text-white opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all pointer-events-none drop-shadow-[0_0_3px_rgba(0,0,0,0.16)]">
          Zurücksetzen
        </span>
      </button>

      <button
        onClick={onFinish}
        className="relative w-[6.94vh] h-[6.94vh] bg-[rgba(18,18,18,0.5)] hover:bg-[#1aaff1] rounded-full flex items-center justify-center transition-all duration-200 group"
      >
        <Check className="w-[1.75vh] h-[1.75vh] text-white" />
        <span className="absolute top-[-3.24vh] whitespace-nowrap text-[1.5vh] font-medium text-white opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all pointer-events-none drop-shadow-[0_0_3px_rgba(0,0,0,0.16)]">
          Fertigstellen
        </span>
      </button>

      <button
        onClick={onRules}
        className="relative w-[6.94vh] h-[6.94vh] bg-[rgba(18,18,18,0.5)] hover:bg-[#1aaff1] rounded-full flex items-center justify-center transition-all duration-200 group"
      >
        <FileText className="w-[1.75vh] h-[1.75vh] text-white" />
        <span className="absolute top-[-3.24vh] whitespace-nowrap text-[1.5vh] font-medium text-white opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all pointer-events-none drop-shadow-[0_0_3px_rgba(0,0,0,0.16)]">
          Regeln
        </span>
      </button>
    </div>
  )
}
