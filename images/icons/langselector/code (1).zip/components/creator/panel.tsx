import type { Step, CharacterData } from "../character-creator"
import { GenderPanel } from "./panels/gender-panel"
import { ParentsPanel } from "./panels/parents-panel"
import { FeaturesPanel } from "./panels/features-panel"
import { HeritagePanel } from "./panels/heritage-panel"
import { AppearancePanel } from "./panels/appearance-panel"

interface PanelProps {
  currentStep: Step
  characterData: CharacterData
  updateCharacterData: (updates: Partial<CharacterData>) => void
}

export function Panel({ currentStep, characterData, updateCharacterData }: PanelProps) {
  return (
    <div className="absolute right-[2.5vh] top-[12vh] w-[45vh] bg-[rgba(18,18,18,0.85)] rounded-[1vh] flex flex-col backdrop-blur-sm">
      {currentStep === "genderParents" && (
        <>
          <GenderPanel gender={characterData.gender} updateCharacterData={updateCharacterData} />
          <div className="h-[0.1vh] bg-[rgba(255,255,255,0.1)] mx-[2vh]" />
          <ParentsPanel parents={characterData.parents} updateCharacterData={updateCharacterData} />
        </>
      )}
      {currentStep === "features" && (
        <FeaturesPanel features={characterData.features} updateCharacterData={updateCharacterData} />
      )}
      {currentStep === "heritage" && (
        <HeritagePanel heritage={characterData.heritage} updateCharacterData={updateCharacterData} />
      )}
      {currentStep === "appearance" && (
        <AppearancePanel appearance={characterData.appearance} updateCharacterData={updateCharacterData} />
      )}
    </div>
  )
}
